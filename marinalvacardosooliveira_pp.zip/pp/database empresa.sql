JOIN departamento d ON f.idDepto = d.departamentoid

WHERE f.funcao = 'Segurança' AND d.nome = 'Saneamento';

SELECT f.nome

FROM funcionario f

JOIN departamento d ON f.idDepto = d.departamentoid

WHERE d.nome = 'RH';

SELECT f.nome, d.nome AS departamento

FROM funcionario f

JOIN departamento d ON f.idDepto = d.departamentoid

WHERE f.salario BETWEEN 500.00 AND 1500.00;

SELECT f.*

FROM funcionario f

JOIN departamento d ON f.idDepto = d.departamentoid

WHERE d.nome = 'TI' AND f.salario > 2000;

tem menu de contexto
 
	
 
CREATE DATABASE Empresa	;

USE Empresa;
 
CREATE TABLE Departamento (

    SetorID INT PRIMARY KEY,

    Nome VARCHAR(30)

);
 
CREATE TABLE Funcionario (

    FuncionarioID INT PRIMARY KEY,

    Nome VARCHAR(30),

    função VARCHAR(30),

    Dtnascto DATE,

    Salario DECIMAL(10,2),

    idDepto INT,

    FOREIGN KEY (idDepto) REFERENCES Departamento(idDepto)

);
 
SELECT * FROM Funcionario

where year(Dtnascto) <> 1975;
 
SELECT * FROM Funcionario

WHERE Nome LIKE '%EM%';
 
SELECT DISTINCT  funcao

From funcionario
 
Select funcionario .nome

From funcionario

Join departamento ON

Funcionario .IdDepto =

Departamento .departamentoId

Where funcionario .funcao =

‘Seguranca’ AND Departamento .nome =

‘Saneamento’ ;

SELECT funcionario .Nome

FROM Funcionario 

Join departamento ON

Funcionario .IdDepto =

Departamento .departamentoId

Where departamento .nome = ‘RH’ ;
 
 
Select funcionario.nome,

Departamento.nome

From funcionario

Join departamento ON

Funcionario . idDepto =

Departamento . departamentoId

Where funcionario. Salario >=500.00 

and  funcionario .salario <= 1500.00;
 
SELECT funcionario .nome,

Departamento .nome

FROM Funcionario

JOIN departamento ON

Funcionario . IdDepto =

Departamento .departamentoId

WHERE departamento .nome = ‘TI’ 

And funcionario. Salario > 2500.00;

 