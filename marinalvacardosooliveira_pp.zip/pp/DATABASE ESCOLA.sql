CREATE DATABASE ESCOLA;
USE ESCOLA;
CREATE TABLE aluno (
    idaluno INT PRIMARY KEY,
    nome VARCHAR(45),
    dataNasc DATE,
    valorMensalidade DECIMAL(7, 2),
    rg VARCHAR(45),
    telefone VARCHAR(9)
);
CREATE TABLE curso (
    idcurso INT PRIMARY KEY,
    descricao VARCHAR(45),
    cargaHoraria INT,
    diaSemana VARCHAR(45)
);
CREATE TABLE alunoCurso (
    idaluno INT,
    idcurso INT,
    PRIMARY KEY (idaluno, idcurso),
    FOREIGN KEY (idaluno) REFERENCES aluno(idaluno),
    FOREIGN KEY (idcurso) REFERENCES curso(idcurso)
);
SELECT * FROM curso;
SELECT * FROM aluno
WHERE YEAR(dataNasc) != 1980;
SELECT a.nome, c.descricao 
FROM aluno a
JOIN alunoCurso ac ON a.idaluno = ac.idaluno
JOIN curso c ON ac.idcurso = c.idcurso;
SELECT * FROM curso
WHERE diaSemana = 'segunda-feira';
SELECT AVG(valorMensalidade) AS mediaMensalidade
FROM aluno
WHERE nome LIKE 'H%';
SELECT * FROM aluno
WHERE valorMensalidade < 230;
SELECT COUNT(a.idaluno) AS numAlunos
FROM aluno a
JOIN alunoCurso ac ON a.idaluno = ac.idaluno
JOIN curso c ON ac.idcurso = c.idcurso
WHERE c.descricao = 'Contabilidade' AND c.diaSemana = 'quarta-feira';
SELECT SUM(a.valorMensalidade) AS totalPago
FROM aluno a
JOIN alunoCurso ac ON a.idaluno = ac.idaluno
JOIN curso c ON ac.idcurso = c.idcurso
WHERE c.descricao = 'Informática Básica';
SELECT DISTINCT c.descricao
FROM aluno a
JOIN alunoCurso ac ON a.idaluno = ac.idaluno
JOIN curso c ON ac.idcurso = c.idcurso
WHERE YEAR(a.dataNasc) = 1995;
SELECT a.nome, a.telefone
FROM aluno a
JOIN alunoCurso ac ON a.idaluno = ac.idaluno
JOIN curso c ON ac.idcurso = c.idcurso
WHERE c.descricao = 'RH';

